package com.vz.eventlog.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.vz.eventlog.model.User;

@Controller
public class MainController {
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);

	@GetMapping("/")
	public String root() {
		String methodName = "root";
		logger.info(methodName + " Method invoked :: ");
		return "index";
	}

	@GetMapping("/login")
	public String login(Model model) {
		User user = new User();
		

		logger.info("login Method invoked :: ");
		return "login";
	}

	@GetMapping("/user")
	public String userIndex() {
		String methodName = "userIndex";
		logger.info(methodName + " Method invoked :: ");
		return "user/index";
	}
}
