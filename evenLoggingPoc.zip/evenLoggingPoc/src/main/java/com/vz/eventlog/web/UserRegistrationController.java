package com.vz.eventlog.web;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.vz.eventlog.model.User;
import com.vz.eventlog.service.UserService;
import com.vz.eventlog.web.dto.UserRegistrationDto;

@Controller
@RequestMapping("/registration")
public class UserRegistrationController {
	
	public static String lastModifiedName="";
	
	private static final Logger logger = LoggerFactory.getLogger(UserRegistrationController.class);
	
	
    @Autowired
    private UserService userService;

    @ModelAttribute("user")
    public UserRegistrationDto userRegistrationDto() {
    	logger.info("userRegistrationDto Method invoked :: UserRegistrationController");
        return new UserRegistrationDto();
    }

    @GetMapping
    public String showRegistrationForm(Model model) {
    	logger.info("showRegistrationForm Method invoked :: UserRegistrationController");
        return "registration";
    }

    @PostMapping
    public String registerUserAccount(@ModelAttribute("user") @Valid UserRegistrationDto userDto,
                                      BindingResult result){

        User existing = userService.findByEmail(userDto.getEmail());
        if (existing != null){
        	logger.info("registerUserAccount Method invoked :: UserRegistrationController and User Information is >>" +existing.toString());
            result.rejectValue("email", null, "There is already an account registered with that email");
        }

        if (result.hasErrors()){
        	logger.error("registerUserAccount Method invoked :: UserRegistrationController and Error is >>"+result.toString());
            return "registration";
        }
        lastModifiedName = userDto.getLastModifiedBy();
        User savedData = userService.save(userDto);
        if(savedData!=null) {        	
        	String res="Resgistraion Success";
        	logger.info(res+" registerUserAccount Method invoked :: UserRegistrationController and User Information is >>" +savedData.toString());
        }else {
        	String res="Resgistraion Failed";
        	logger.error(res+" registerUserAccount Method invoked :: UserRegistrationController and User Information is >>" +userDto.toString()+" Please Register again");
        }
        return "redirect:/registration?success";
    }

}
