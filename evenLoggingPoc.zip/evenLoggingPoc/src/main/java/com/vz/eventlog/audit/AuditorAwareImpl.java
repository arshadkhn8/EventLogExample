package com.vz.eventlog.audit;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;

import com.vz.eventlog.web.UserRegistrationController;


public class AuditorAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		
		return Optional.of(UserRegistrationController.lastModifiedName);
	}
}
